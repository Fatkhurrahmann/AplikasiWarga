<?php
// Allow CORS for remote requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Database connection settings
$host = 'localhost';
$user = 'teky6584_api_dzaky';
$password = 'zDr19cuU4E1e43';
$dbname = 'teky6584_api_dzaky';

// Enable error reporting for development (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log'); // Log errors to a file

// Create a connection to the database
$conn = new mysqli($host, $user, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    // If the connection fails, output an error in JSON format
    die(json_encode([
        'status' => 'error',
        'message' => 'Database connection failed',
        'error_code' => $conn->connect_errno, // Optional for development
        'error_message' => $conn->connect_error // Optional for development
    ]));
}

// Optional success message for testing
// echo json_encode(['status' => 'success', 'message' => 'Database connection successful']);
?>
