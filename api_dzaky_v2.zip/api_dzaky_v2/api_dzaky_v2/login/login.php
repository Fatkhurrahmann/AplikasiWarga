<?php
header('Content-Type: application/json');
include '../config/config.php';

// Mulai sesi terlebih dahulu
session_start();

// Ambil data dari request
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi input kosong
if (empty($username) || empty($password)) {
    echo json_encode(['status' => 'error', 'message' => 'Username dan password wajib diisi']);
    exit;
}

// Hash password dengan MD5
$hashed_password = md5($password);

// Validasi ke database
$query = $conn->prepare("SELECT * FROM user WHERE username_user = ? AND password_user = ?");
$query->bind_param('ss', $username, $hashed_password);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    // Ambil data pengguna dari hasil query
    $user = $result->fetch_assoc();

    // Simpan id_user dalam sesi
    $_SESSION['id_user'] = $user['id_user']; // Simpan id_user di sesi

    // Kembalikan respons sukses
    echo json_encode([
        'status' => 'success',
        'message' => 'Login berhasil',
        'data' => $user // Menampilkan data pengguna jika perlu
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Username atau password salah']);
}
?>
