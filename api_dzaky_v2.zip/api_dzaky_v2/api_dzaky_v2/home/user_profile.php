<?php
include('../config/config.php');  // Pastikan file config.php benar dan sudah koneksi ke DB

header('Content-Type: application/json'); // Tentukan bahwa response dalam format JSON

// Periksa apakah ID pengguna ada dalam request
if (isset($_GET['id_user'])) {
    $get_id_user = intval($_GET['id_user']);
} else {
    echo json_encode(['error' => 'ID pengguna tidak diberikan']);
    exit();
}

// Ambil data pengguna dari database
$query = "SELECT * FROM user WHERE id_user = $get_id_user";
$hasil = $conn->query($query);

// Cek hasil query
if ($hasil) {
    $data_user = $hasil->fetch_assoc();
    if ($data_user) {
        echo json_encode($data_user);  // Kirim data sebagai JSON
    } else {
        echo json_encode(['error' => 'Pengguna tidak ditemukan']);
    }
} else {
    echo json_encode(['error' => 'Query gagal: ' . $conn->error]);
}
?>
