<?php
// Sertakan file konfigurasi
require_once '../config/config.php';

// Periksa koneksi
if (!$conn) {
    die(json_encode(['status' => 'error', 'message' => 'Koneksi database tidak tersedia.']));
}

// Query untuk menghitung total data warga
$sqlTotalWarga = "SELECT COUNT(*) AS total_warga FROM warga";
$resultTotalWarga = mysqli_query($conn, $sqlTotalWarga);
$dataTotalWarga = mysqli_fetch_assoc($resultTotalWarga);

// Query untuk menghitung warga laki-laki
$sqlWargaLaki = "SELECT COUNT(*) AS total FROM warga WHERE jenis_kelamin_warga = 'L'";
$resultWargaLaki = mysqli_query($conn, $sqlWargaLaki);
$dataWargaLaki = mysqli_fetch_assoc($resultWargaLaki);

// Query untuk menghitung warga perempuan
$sqlWargaPerempuan = "SELECT COUNT(*) AS total FROM warga WHERE jenis_kelamin_warga = 'P'";
$resultWargaPerempuan = mysqli_query($conn, $sqlWargaPerempuan);
$dataWargaPerempuan = mysqli_fetch_assoc($resultWargaPerempuan);

// Query untuk menghitung total kartu keluarga
$sqlTotalKK = "SELECT COUNT(*) AS total_kartu_keluarga FROM kartu_keluarga";
$resultTotalKK = mysqli_query($conn, $sqlTotalKK);
$dataTotalKK = mysqli_fetch_assoc($resultTotalKK);

// Query untuk menghitung total mutasi
$sqlTotalMutasi = "SELECT COUNT(*) AS total_mutasi FROM mutasi";
$resultTotalMutasi = mysqli_query($conn, $sqlTotalMutasi);
$dataTotalMutasi = mysqli_fetch_assoc($resultTotalMutasi);

// Query untuk mengambil nama user
$sqlNamaUser = "SELECT nama_user FROM user WHERE id_user = 1"; // Sesuaikan dengan ID user Anda
$resultNamaUser = mysqli_query($conn, $sqlNamaUser);
$dataNamaUser = mysqli_fetch_assoc($resultNamaUser);

// Susun data untuk dikembalikan
$response = [
    'status' => 'success',
    'data' => [
        'total_warga' => (int) $dataTotalWarga['total_warga'],
        'total_laki_laki' => (int) $dataWargaLaki['total'],
        'total_perempuan' => (int) $dataWargaPerempuan['total'],
        'total_kartu_keluarga' => (int) $dataTotalKK['total_kartu_keluarga'],
        'total_mutasi' => (int) $dataTotalMutasi['total_mutasi'],
        'nama_user' => $dataNamaUser['nama_user'] ?? 'Pengguna', // Default ke 'Pengguna' jika tidak ditemukan
    ],
];

// Tutup koneksi
mysqli_close($conn);

// Kembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
