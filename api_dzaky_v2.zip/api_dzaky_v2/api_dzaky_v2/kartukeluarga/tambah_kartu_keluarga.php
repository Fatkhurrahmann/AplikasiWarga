<?php
// Include file config.php untuk koneksi ke database
include '../config/config.php';

// Memeriksa apakah data yang diperlukan ada dalam POST
if (!isset($_POST['nomor_keluarga']) || !isset($_POST['id_kepala_keluarga']) || !isset($_POST['alamat_keluarga']) || 
    !isset($_POST['desa_kelurahan_keluarga']) || !isset($_POST['kecamatan_keluarga']) || !isset($_POST['kabupaten_kota_keluarga']) ||
    !isset($_POST['provinsi_keluarga']) || !isset($_POST['negara_keluarga']) || !isset($_POST['rt_keluarga']) || 
    !isset($_POST['rw_keluarga']) || !isset($_POST['kode_pos_keluarga']) || !isset($_POST['id_user']) || 
    !isset($_POST['created_at']) || !isset($_POST['updated_at'])) {
    echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
    exit;
}

// Ambil data dari POST
$nomor_keluarga = $_POST['nomor_keluarga'];
$id_kepala_keluarga = $_POST['id_kepala_keluarga'];
$alamat_keluarga = $_POST['alamat_keluarga'];
$desa_kelurahan_keluarga = $_POST['desa_kelurahan_keluarga'];
$kecamatan_keluarga = $_POST['kecamatan_keluarga'];
$kabupaten_kota_keluarga = $_POST['kabupaten_kota_keluarga'];
$provinsi_keluarga = $_POST['provinsi_keluarga'];
$negara_keluarga = $_POST['negara_keluarga'];
$rt_keluarga = $_POST['rt_keluarga'];
$rw_keluarga = $_POST['rw_keluarga'];
$kode_pos_keluarga = $_POST['kode_pos_keluarga'];
$id_user = $_POST['id_user'];
$created_at = $_POST['created_at'];
$updated_at = $_POST['updated_at'];

// Memeriksa apakah id_kepala_keluarga valid
$query_check_kepala = "SELECT * FROM warga WHERE id_warga = '$id_kepala_keluarga'";
$result_check_kepala = $conn->query($query_check_kepala);

if ($result_check_kepala->num_rows == 0) {
    echo json_encode(['status' => 'error', 'message' => 'Kepala Keluarga tidak ditemukan']);
    exit;
}

// Query untuk menyimpan data ke dalam tabel kartu_keluarga
$stmt = $conn->prepare("INSERT INTO kartu_keluarga 
(nomor_keluarga, id_kepala_keluarga, alamat_keluarga, desa_kelurahan_keluarga, kecamatan_keluarga, 
kabupaten_kota_keluarga, provinsi_keluarga, negara_keluarga, rt_keluarga, rw_keluarga, kode_pos_keluarga, 
id_user, created_at, updated_at) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Bind parameter
$stmt->bind_param("ssssssssssssss", $nomor_keluarga, $id_kepala_keluarga, $alamat_keluarga, 
    $desa_kelurahan_keluarga, $kecamatan_keluarga, $kabupaten_kota_keluarga, $provinsi_keluarga, $negara_keluarga, 
    $rt_keluarga, $rw_keluarga, $kode_pos_keluarga, $id_user, $created_at, $updated_at);

// Eksekusi query
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Data berhasil disimpan']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data']);
}

// Tutup statement dan koneksi
$stmt->close();
$conn->close();
?>
