<?php
// jumlah_keluarga.php

// Mengimpor file konfigurasi
include('../config/config.php');

// Menerima id_keluarga dari parameter GET
$id_keluarga = isset($_GET['id_keluarga']) ? $_GET['id_keluarga'] : null;

// Cek apakah id_keluarga tersedia
if ($id_keluarga) {
    // Query untuk mengambil data anggota keluarga berdasarkan id_keluarga
    $sql = "SELECT * FROM warga WHERE id_keluarga = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_keluarga);
    $stmt->execute();
    $result = $stmt->get_result();

    // Membuat array untuk menyimpan data anggota keluarga
    $anggota_keluarga = array();

    while ($row = $result->fetch_assoc()) {
        $anggota_keluarga[] = $row;
    }

    // Mengembalikan data anggota keluarga dalam format JSON
    echo json_encode($anggota_keluarga);

} else {
    // Jika id_keluarga tidak ada
    echo json_encode(["error" => "id_keluarga tidak ditemukan."]);
}

// Menutup koneksi
$conn->close();
?>
