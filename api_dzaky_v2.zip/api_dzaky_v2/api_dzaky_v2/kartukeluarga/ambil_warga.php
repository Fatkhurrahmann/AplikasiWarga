<?php
// Koneksi ke database
include '../config/config.php';

// Query untuk mengambil data nama_warga dan nik_warga dari tabel warga
$sql = "SELECT id_warga, nama_warga, nik_warga FROM warga";

// Menjalankan query
$result = $conn->query($sql);

// Menyiapkan array untuk menampung hasil
$warga = array();

// Mengecek apakah ada data yang ditemukan
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Menambahkan data warga ke dalam array
        $warga[] = array(
            'id_warga' => $row['id_warga'],
            'nama_warga' => $row['nama_warga'],
            'nik_warga' => $row['nik_warga']
        );
    }
    // Menyusun respon dalam format JSON
    echo json_encode(['status' => 'success', 'warga' => $warga]);
} else {
    // Menyusun respon jika tidak ada data
    echo json_encode(['status' => 'error', 'message' => 'No data found']);
}

// Menutup koneksi
$conn->close();
?>
