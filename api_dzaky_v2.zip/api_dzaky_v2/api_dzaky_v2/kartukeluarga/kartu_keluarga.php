<?php
// Include file config.php untuk koneksi ke database
include '../config/config.php';

// Query untuk mengambil data kartu keluarga beserta semua kolom terkait
$query = "
    SELECT 
        k.id_keluarga,
        k.nomor_keluarga,
        k.id_kepala_keluarga,
        k.alamat_keluarga,
        k.desa_kelurahan_keluarga,
        k.kecamatan_keluarga,
        k.kabupaten_kota_keluarga,
        k.provinsi_keluarga,
        k.negara_keluarga,
        k.rt_keluarga,
        k.rw_keluarga,
        k.kode_pos_keluarga,
        w.nama_warga,
        w.nik_warga
    FROM kartu_keluarga k
    LEFT JOIN warga w ON k.id_kepala_keluarga = w.id_warga
";

// Menjalankan query
$result = $conn->query($query);

// Cek apakah ada data yang ditemukan
if ($result->num_rows > 0) {
    $kartuKeluargaArray = [];

    // Mengambil data dan memasukkan ke dalam array
    while ($row = $result->fetch_assoc()) {
        $kartuKeluargaArray[] = $row;
    }

    // Outputkan data kartu keluarga dalam format JSON
    echo json_encode([
        'status' => 'success',  // Menambahkan status sebagai indikasi keberhasilan
        'message' => 'Data ditemukan',
        'kartu_keluarga' => $kartuKeluargaArray
    ]);
} else {
    // Jika data tidak ditemukan, berikan respons yang sesuai
    echo json_encode([
        'status' => 'error',  // Status error jika tidak ada data
        'message' => 'Data tidak ditemukan',
        'kartu_keluarga' => []
    ]);
}

// Menutup koneksi database
$conn->close();
?>
