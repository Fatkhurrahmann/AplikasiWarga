<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/config.php'; // Include the database configuration

$response = [];

try {
    // Get data from POST request
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $pendidikan_terakhir = $_POST['pendidikan_terakhir'];
    $pekerjaan = $_POST['pekerjaan'];
    $status_perkawinan = $_POST['status_perkawinan'];
    $status_warga = $_POST['status_warga'];

    // SQL query to update the citizen's data
    $query = "UPDATE warga SET 
                nama_warga = ?, 
                jenis_kelamin_warga = ?, 
                tanggal_lahir_warga = ?, 
                pendidikan_terakhir_warga = ?, 
                pekerjaan_warga = ?, 
                status_perkawinan_warga = ?, 
                status_warga = ? 
              WHERE nik_warga = ?";

    $stmt = mysqli_prepare($conn, $query);

    if (!$stmt) {
        throw new Exception('Error preparing statement: ' . mysqli_error($conn));
    }

    // Bind the parameters to the prepared statement
    mysqli_stmt_bind_param($stmt, "ssssssss", $nama, $jenis_kelamin, $tanggal_lahir, $pendidikan_terakhir, $pekerjaan, $status_perkawinan, $status_warga, $nik);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        $response['success'] = 'Data updated successfully';
    } else {
        throw new Exception('Error updating data: ' . mysqli_error($conn));
    }

    echo json_encode($response);

    mysqli_stmt_close($stmt);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
