<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/config.php'; // Pastikan file config.php sudah ada untuk koneksi ke database

$response = [];

try {
    // Query untuk mengambil data warga lengkap
    $query = "SELECT nama_warga AS nama, nik_warga AS nik, jenis_kelamin_warga AS jenis_kelamin, 
                TIMESTAMPDIFF(YEAR, tanggal_lahir_warga, CURDATE()) AS usia, 
                pendidikan_terakhir_warga AS pendidikan, pekerjaan_warga AS pekerjaan, 
                status_perkawinan_warga AS status_kawin, status_warga AS status 
              FROM warga";
    $result = mysqli_query($conn, $query);

    // Cek apakah query berhasil
    if (!$result) {
        throw new Exception('Error executing query: ' . mysqli_error($conn));
    }

    // Menyimpan data warga dalam array
    $wargaList = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $wargaList[] = $row; // Menambahkan data warga ke dalam array
    }

    // Mengirimkan data warga dalam bentuk JSON
    $response['warga'] = $wargaList;

    echo json_encode($response);

} catch (Exception $e) {
    // Mengirimkan error dalam bentuk JSON jika terjadi exception
    echo json_encode(['error' => $e->getMessage()]);
}
?>
