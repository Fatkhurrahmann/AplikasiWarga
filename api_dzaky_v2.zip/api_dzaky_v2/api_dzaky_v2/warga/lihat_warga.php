<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/config.php';

$response = [];

try {
    // Fetching NIK from request
    if (!isset($_GET['nik'])) {
        throw new Exception('NIK is required');
    }

    $nik = $_GET['nik'];

    // Query to get full details of the citizen by NIK
    $query = "SELECT id_warga, nik_warga, nama_warga, tempat_lahir_warga, tanggal_lahir_warga, jenis_kelamin_warga, 
                     alamat_ktp_warga, alamat_warga, desa_kelurahan_warga, kecamatan_warga, kabupaten_kota_warga, 
                     provinsi_warga, negara_warga, rt_warga, rw_warga, agama_warga, pendidikan_terakhir_warga, 
                     pekerjaan_warga, status_perkawinan_warga, status_warga, id_user, created_at, updated_at 
              FROM warga WHERE nik_warga = ?";
    $stmt = mysqli_prepare($conn, $query);

    if (!$stmt) {
        throw new Exception('Error preparing statement: ' . mysqli_error($conn));
    }

    // Bind the NIK parameter to the prepared statement
    mysqli_stmt_bind_param($stmt, "s", $nik);

    // Execute the prepared statement
    mysqli_stmt_execute($stmt);

    // Get the result
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $data = mysqli_fetch_assoc($result);

        if ($data) {
            $response['data'] = $data;
        } else {
            $response['error'] = 'Data not found';
        }

        echo json_encode($response);
    } else {
        throw new Exception('Error fetching details: ' . mysqli_error($conn));
    }

    mysqli_stmt_close($stmt);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>
