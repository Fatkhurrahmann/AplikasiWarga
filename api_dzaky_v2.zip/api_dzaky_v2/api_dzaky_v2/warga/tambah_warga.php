<?php
include '../config/config.php'; // Koneksi database

header('Content-Type: application/json');

// Pastikan data yang dikirim sesuai dengan yang diharapkan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari input POST
    $nik = $_POST['nik_warga'] ?? '';
    $nama = $_POST['nama_warga'] ?? '';
    $tempat_lahir = $_POST['tempat_lahir_warga'] ?? '';
    $tanggal_lahir = $_POST['tanggal_lahir_warga'] ?? '';
    $jenis_kelamin = $_POST['jenis_kelamin_warga'] ?? '';
    $alamat_ktp = $_POST['alamat_ktp_warga'] ?? '';
    $alamat = $_POST['alamat_warga'] ?? '';
    $desa_kelurahan = $_POST['desa_kelurahan_warga'] ?? '';
    $kecamatan = $_POST['kecamatan_warga'] ?? '';
    $kabupaten_kota = $_POST['kabupaten_kota_warga'] ?? '';
    $provinsi = $_POST['provinsi_warga'] ?? '';
    $negara = $_POST['negara_warga'] ?? '';
    $rt = $_POST['rt_warga'] ?? '';
    $rw = $_POST['rw_warga'] ?? '';
    $agama = $_POST['agama_warga'] ?? '';
    $pendidikan_terakhir = $_POST['pendidikan_terakhir_warga'] ?? '';
    $pekerjaan = $_POST['pekerjaan_warga'] ?? '';
    $status_perkawinan = $_POST['status_perkawinan_warga'] ?? '';
    $status_warga = $_POST['status_warga'] ?? '';
    $id_user = $_POST['id_user'] ?? '';

    // Validasi apakah semua data wajib telah diisi
    if (empty($nik) || empty($nama) || empty($tempat_lahir) || empty($tanggal_lahir) || empty($jenis_kelamin) ||
        empty($alamat_ktp) || empty($alamat) || empty($desa_kelurahan) || empty($kecamatan) ||
        empty($kabupaten_kota) || empty($provinsi) || empty($negara) || empty($rt) || empty($rw) ||
        empty($agama) || empty($pendidikan_terakhir) || empty($pekerjaan) || empty($status_perkawinan) ||
        empty($status_warga) || empty($id_user)) {
        echo json_encode(['error' => 'Semua kolom wajib diisi']);
        exit;
    }

    // Format tanggal lahir menjadi Y-m-d
    $tanggal_lahir = date('Y-m-d', strtotime($tanggal_lahir));

    // Debug: Cek nilai data yang akan dimasukkan
    // echo json_encode(['data' => $_POST]); exit;

    // Gunakan prepared statements untuk mencegah SQL Injection
    $stmt = $conn->prepare(
        "INSERT INTO warga (
            nik_warga, nama_warga, tempat_lahir_warga, tanggal_lahir_warga, jenis_kelamin_warga, 
            alamat_ktp_warga, alamat_warga, desa_kelurahan_warga, kecamatan_warga, kabupaten_kota_warga, 
            provinsi_warga, negara_warga, rt_warga, rw_warga, agama_warga, 
            pendidikan_terakhir_warga, pekerjaan_warga, status_perkawinan_warga, status_warga, id_user, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())"
    );

    // Periksa apakah query berhasil disiapkan
    if ($stmt === false) {
        echo json_encode(['error' => 'Query preparation failed', 'detail' => $conn->error]);
        exit;
    }

    // Bind parameter dengan prepared statement
    $stmt->bind_param(
        "ssssssssssssssssssss", 
        $nik, $nama, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $alamat_ktp, $alamat, $desa_kelurahan, 
        $kecamatan, $kabupaten_kota, $provinsi, $negara, $rt, $rw, $agama, 
        $pendidikan_terakhir, $pekerjaan, $status_perkawinan, $status_warga, $id_user
    );

    // Eksekusi query dan cek hasilnya
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Data warga berhasil ditambahkan']);
    } else {
        echo json_encode([
            'error' => 'Gagal menambahkan data warga',
            'detail' => $stmt->error // Menampilkan error query
        ]);
    }

    $stmt->close(); // Tutup statement
} else {
    echo json_encode(['error' => 'Metode HTTP tidak didukung']);
}
?>
