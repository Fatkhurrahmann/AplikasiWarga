<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/config.php';

$response = [];

try {
    // Periksa apakah parameter NIK dikirimkan
    if (!isset($_POST['nik'])) {
        throw new Exception('NIK diperlukan');
    }

    $nik = $_POST['nik'];

    // Validasi format NIK (16 digit angka)
    if (!preg_match('/^\d{16}$/', $nik)) {
        throw new Exception('Invalid NIK format');
    }

    // Cari ID warga berdasarkan NIK
    $querySelect = "SELECT id_warga FROM warga WHERE nik_warga = '$nik'";
    $resultSelect = mysqli_query($conn, $querySelect);

    if (!$resultSelect || mysqli_num_rows($resultSelect) === 0) {
        throw new Exception('Tidak ditemukan data untuk NIK yang diberikan');
    }

    $row = mysqli_fetch_assoc($resultSelect);
    $id_warga = $row['id_warga'];

    // Hapus data terkait di tabel kartu_keluarga jika ada
    $queryDeleteKK = "DELETE FROM kartu_keluarga WHERE id_kepala_keluarga = '$id_warga'";
    $resultDeleteKK = mysqli_query($conn, $queryDeleteKK);

    if (!$resultDeleteKK) {
        throw new Exception('kesalahan saat menghapus data terkait di kartu_keluarga: ' . mysqli_error($conn));
    }

    // Hapus data di tabel warga
    $queryDeleteWarga = "DELETE FROM warga WHERE nik_warga = '$nik'";
    $resultDeleteWarga = mysqli_query($conn, $queryDeleteWarga);

    if (!$resultDeleteWarga) {
        throw new Exception('Kesalahan saat menghapus data di warga: ' . mysqli_error($conn));
    }

    // Respon sukses
    $response['message'] = 'Data berhasil dihapus';
    echo json_encode($response);

} catch (Exception $e) {
    // Respon error
    echo json_encode(['error' => $e->getMessage()]);
}

// Tutup koneksi database
mysqli_close($conn);
?>
