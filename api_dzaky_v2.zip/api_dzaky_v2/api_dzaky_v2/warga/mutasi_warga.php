<?php
header('Content-Type: application/json');
require '../config/config.php'; // Pastikan file koneksi database benar

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'] ?? null;
    $id_mutasi = $_POST['id_mutasi'] ?? null;
    $id_user = $_POST['id_user'] ?? null;

    if (empty($nik) || empty($id_mutasi) || empty($id_user)) {
        echo json_encode(['error' => 'NIK, ID Mutasi, atau ID User tidak boleh kosong']);
        exit();
    }

    // Debugging: Log data yang diterima
    error_log("NIK: $nik, ID Mutasi: $id_mutasi, ID User: $id_user");

    // Periksa apakah NIK ada di tabel warga
    $stmt = $conn->prepare("SELECT * FROM warga WHERE nik_warga = ?");
    $stmt->bind_param('s', $nik);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $wargaData = $result->fetch_assoc();

        // Periksa apakah ID User ada di tabel user
        $stmt = $conn->prepare("SELECT * FROM user WHERE id_user = ?");
        $stmt->bind_param('s', $id_user);
        $stmt->execute();
        $userResult = $stmt->get_result();

        if ($userResult->num_rows == 0) {
            echo json_encode(['error' => 'ID User tidak ditemukan di tabel user']);
            exit();
        }

        // Lakukan pemindahan data ke tabel mutasi
        $stmt = $conn->prepare("
            INSERT INTO mutasi (
                nik_mutasi, nama_mutasi, tempat_lahir_mutasi, tanggal_lahir_mutasi,
                jenis_kelamin_mutasi, alamat_ktp_mutasi, alamat_mutasi, desa_kelurahan_mutasi,
                kecamatan_mutasi, kabupaten_kota_mutasi, provinsi_mutasi, negara_mutasi,
                rt_mutasi, rw_mutasi, agama_mutasi, pendidikan_terakhir_mutasi, pekerjaan_mutasi,
                status_perkawinan_mutasi, status_mutasi, id_user, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param(
            'ssssssssssssssssssss',
            $wargaData['nik_warga'], $wargaData['nama_warga'], $wargaData['tempat_lahir_warga'],
            $wargaData['tanggal_lahir_warga'], $wargaData['jenis_kelamin_warga'], $wargaData['alamat_ktp_warga'],
            $wargaData['alamat_warga'], $wargaData['desa_kelurahan_warga'], $wargaData['kecamatan_warga'],
            $wargaData['kabupaten_kota_warga'], $wargaData['provinsi_warga'], $wargaData['negara_warga'],
            $wargaData['rt_warga'], $wargaData['rw_warga'], $wargaData['agama_warga'],
            $wargaData['pendidikan_terakhir_warga'], $wargaData['pekerjaan_warga'], $wargaData['status_perkawinan_warga'],
            $wargaData['status_warga'], $id_user
        );

        if ($stmt->execute()) {
            // Hapus data dari tabel warga
            $deleteStmt = $conn->prepare("DELETE FROM warga WHERE nik_warga = ?");
            $deleteStmt->bind_param('s', $nik);
            $deleteStmt->execute();

            echo json_encode(['success' => 'Data berhasil dipindahkan ke tabel mutasi']);
        } else {
            echo json_encode(['error' => 'Gagal memindahkan data ke tabel mutasi']);
        }
    } else {
        echo json_encode(['error' => 'NIK tidak ditemukan di tabel warga']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['error' => 'Metode request tidak valid']);
}
?>
