<?php
include '../config/config.php';
header('Content-Type: application/json');

// Ambil ID mutasi dari parameter POST
$id_mutasi = isset($_POST['id_mutasi']) ? (int)$_POST['id_mutasi'] : 0;

if ($id_mutasi <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID tidak valid']);
    exit;
}

$query = "DELETE FROM mutasi WHERE id_mutasi = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_mutasi);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Data berhasil dihapus']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus data']);
}

$stmt->close();
$conn->close();
?>
