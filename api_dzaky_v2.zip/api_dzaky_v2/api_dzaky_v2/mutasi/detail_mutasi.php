<?php
// Include database connection
include('../config/config.php');  // Ganti path sesuai kebutuhan

// Get the id_mutasi parameter from the URL
$id_mutasi = isset($_GET['id_mutasi']) ? $_GET['id_mutasi'] : null;

if ($id_mutasi) {
    // SQL query to fetch the mutation details based on the id_mutasi
    $query = "SELECT * FROM mutasi WHERE id_mutasi = ?";
    
    // Prepare and execute the query
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $id_mutasi);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if we found the mutation
        if ($result->num_rows > 0) {
            // Fetch the result as an associative array
            $data = $result->fetch_assoc();
            
            // Return the result as JSON
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
            // If no data is found, return an error message
            header('Content-Type: application/json');
            echo json_encode(["error" => "Data not found"]);
        }

        // Close the statement
        $stmt->close();
    } else {
        echo json_encode(["error" => "Failed to prepare the query"]);
    }
} else {
    echo json_encode(["error" => "Invalid or missing id_mutasi"]);
}

// Close the database connection
$conn->close();
?>
