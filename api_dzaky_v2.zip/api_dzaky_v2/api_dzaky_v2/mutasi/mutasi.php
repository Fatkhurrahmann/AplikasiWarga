<?php
// Mengimpor file config.php untuk koneksi database
include('../config/config.php');

// Menampilkan data mutasi
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['id_mutasi'])) {
    $sql = "SELECT * FROM mutasi";
    $result = $conn->query($sql);
    $mutasiList = [];

    while ($row = $result->fetch_assoc()) {
        $mutasiList[] = $row;
    }

    echo json_encode($mutasiList);
}

// Menampilkan detail data mutasi
if (isset($_GET['id_mutasi'])) {
    $idMutasi = $_GET['id_mutasi'];
    $sql = "SELECT * FROM mutasi WHERE id_mutasi = $idMutasi";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data);
    } else {
        echo json_encode(['error' => 'Data tidak ditemukan']);
    }
}

// Menghapus data mutasi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_mutasi'])) {
    $idMutasi = $_POST['id_mutasi'];
    $sql = "DELETE FROM mutasi WHERE id_mutasi = $idMutasi";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting data: ' . $conn->error]);
    }
}

// Menutup koneksi
$conn->close();
?>
